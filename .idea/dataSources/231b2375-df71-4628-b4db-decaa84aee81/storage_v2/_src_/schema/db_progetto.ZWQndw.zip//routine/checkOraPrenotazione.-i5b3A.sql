create
    definer = root@localhost procedure checkOraPrenotazione(IN azienda int, IN data_pr date, IN ora time)
checkPrenotazione: BEGIN
	SELECT count(*) as Num_Prenotazioni FROM tabella_prenotazioni as T WHERE T.id_azienda = azienda  and T.data = data_pr and T.ora = ora;
	
END;

