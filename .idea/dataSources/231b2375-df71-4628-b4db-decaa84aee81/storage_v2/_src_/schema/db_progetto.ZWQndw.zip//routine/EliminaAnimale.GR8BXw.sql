create
    definer = root@localhost procedure EliminaAnimale(IN id int(20))
CreaUtente: BEGIN

        IF(EXISTS(SELECT * FROM Animali WHERE id_animale =id))
        then
        DELETE FROM Animali WHERE id_animale = id;
        end if;
        
END;

