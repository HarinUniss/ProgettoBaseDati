create
    definer = root@localhost procedure CreaUtente(IN cognome char(50), IN nome char(50), IN indirizzo char(100),
                                                  IN civico smallint(5), IN citta char(100), IN telefono int(20),
                                                  IN email char(50), IN foto char(200), IN tipo char(12),
                                                  IN dataora datetime, IN username char(50), IN password char(100))
CreaUtente: BEGIN
		DECLARE id int;
        SELECT RAND()*1000000 INTO id;
			
        while EXISTS(SELECT * FROM Utenti WHERE id_utente = id) do
			SELECT RAND()*1000000 INTO id;
        end while;        
        
		INSERT INTO utenti(id_utente, cognome, nome, indirizzo, civico, citta, telefono, email, foto, tipo, dataora)
        VALUES(id, cognome, nome, indirizzo, civico, citta, telefono, email, foto, tipo, dataora);
		INSERT INTO credenziali(username, password, proprietario)
        VALUES(username, password, id);
        
END;

