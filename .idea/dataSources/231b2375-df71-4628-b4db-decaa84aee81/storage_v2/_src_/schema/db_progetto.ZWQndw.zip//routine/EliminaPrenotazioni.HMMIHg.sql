create
    definer = root@localhost procedure EliminaPrenotazioni(IN id int(20))
CreaUtente: BEGIN

        IF(EXISTS(SELECT * FROM tabella_prenotazioni WHERE id_prenotazione =id))
        then
        DELETE from tabella_prenotazioni where id_prenotazione = id;
        end if;
END;

