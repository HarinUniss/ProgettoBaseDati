create
    definer = root@localhost procedure CreaPrenotazione(IN utente int, IN azienda int, IN data_pr date, IN ora time, IN note char)
CreaPrenotazione: BEGIN
		DECLARE numero_prenotazioni int;
        DECLARE data_attuale date;
        SELECT count(*) FROM tabella_prenotazioni as T WHERE T.id_azienda = azienda and T.data = data_pr and T.ora = ora INTO numero_prenotazioni;
        SELECT NOW() INTO data_attuale;
        
        if(numero_prenotazioni < 1) then
			if(SELECT DATEDIFF(ADDATE(data_attuale, 10), data_pr)<10)then
				INSERT INTO tabella_prenotazioni (id_utente, id_azienda, data, ora, note) VALUES
				(utente, azienda, data_pr, note);
			end if;
        end if;
        
        /*1' Controllare La data e l'ora inserita quanti utenti hanno fatto la prenotazione se < 5 prenotiamo, altrimenti no*/
        
END;

